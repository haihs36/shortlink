<div>
    <span title="{{ $date->toDayDateTimeString() }} ">
        {{ $date->shortRelativeDiffForHumans() }}
    </span>
</div>
