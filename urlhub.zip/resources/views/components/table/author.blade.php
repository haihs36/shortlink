<span class="font-semibold">
    <a href="{{ route('dashboard.allurl.u-user', $name) }}">
        {{ $name }}
    </a>
</span>
