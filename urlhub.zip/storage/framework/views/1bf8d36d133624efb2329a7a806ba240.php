<div>
    <a role="button" href="<?php echo e($detail_link); ?>" target="_blank" title="<?php echo e(__('Details')); ?>"
        class="btn btn-secondary btn-sm"
    >
        <?php echo e(svg('icon-chart-line')); ?>
    </a>
    <a role="button" href="<?php echo e($edit_link); ?>" title="<?php echo e(__('Edit')); ?>"
        class="btn btn-secondary btn-sm"
    >
        <?php echo e(svg('icon-edit')); ?>
    </a>
    <a role="button" href="<?php echo e($delete_link); ?>" title="<?php echo e(__('Delete')); ?>"
        class="btn btn-secondary btn-sm hover:text-red-600 active:text-red-700"
    >
        <?php echo e(svg('icon-trash')); ?>
    </a>
</div>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/components/table/action-button.blade.php ENDPATH**/ ?>