<?php $__env->startSection('css_class', 'frontend home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="pt-16 sm:pt-28">
        <?php if(! auth()->check() and ! config('urlhub.public_site')): ?>
            <div class="flex flex-wrap md:justify-center">
                <div class="w-full md:w-8/12 font-thin text-5xl text-slate-600 text-center welcome-msg">
                    <?php echo e(__('Please login to shorten URLs')); ?></div>
            </div>
            <div class="flex flex-wrap md:justify-center mt-12">
                <div class="w-full md:w-7/12">
                    <?php echo $__env->make('partials/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            </div>
        <?php else: ?>
            <div class="flex flex-wrap md:justify-center">
                <h1 class="mx-auto max-w-md md:max-w-3xl relative z-10
                    font-bold text-uh-blue-2 text-center md:text-4xl xl:text-5xl text-3xl !leading-tight"
                >
                    Simple URL shortener <br>
                    <span class="font-thin text-black">for individuals &amp; businesses.</span>
                </h1>
            </div>

            <div class="flex flex-wrap justify-center mt-12 px-4 lg:px-0">
                <div class="w-full max-w-4xl">
                    <form method="post" action="<?php echo e(route('su_create')); ?>" class="mb-4 mt-12" id="formUrl">
                    <?php echo csrf_field(); ?>
                        <div class="mt-1 text-center">
                            <input name="long_url" value="<?php echo e(old('long_url')); ?>" placeholder="<?php echo e(__('Shorten your link')); ?>"
                                class="w-full md:w-4/6 px-2 md:px-4 h-12 sm:h-14
                                    text-xl outline-none
                                    border border-border-uh-border-color focus:border-green-700
                                    rounded-t-md md:rounded-l-md md:rounded-r-none
                                    
                                    border-slate-300 focus:ring-inherit">
                            <button type="submit" id="actProcess"
                                class="w-full md:w-1/6 h-12 sm:h-14 align-top rounded-t-none rounded-b md:rounded-l-none md:rounded-r-md
                                    text-lg text-white bg-green-700 hover:bg-green-800 focus:uh-blue-2"
                            >
                                <?php echo e(__('Shorten')); ?>

                            </button>
                        </div>

                        <br>

                        <div class="custom-url sm:mt-8">
                            <b><?php echo e(__('Custom URL (optional)')); ?></b>
                            <span class="block mb-4 font-light">
                                <?php echo e(__('Replace clunky URLs with meaningful short links that get more clicks.')); ?></span>
                            <div class="inline text-2xl">
                                <?php echo e(request()->getHttpHost()); ?>/ <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('validation.validate-custom-keyword');

$__html = app('livewire')->mount($__name, $__params, 'lw-1395580158-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                            </div>
                        </div>
                    </form>

                    <?php echo $__env->make('partials/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/frontend/homepage.blade.php ENDPATH**/ ?>