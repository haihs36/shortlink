<div class="pt-2 pb-3 space-y-1">
    <a href="<?php echo e(route('dashboard')); ?>"
        class="nav-item <?php echo e((request()->route()->getName() === 'dashboard') ? 'border-l-2 border-orange-500':''); ?>">
        <?php echo e(svg('icon-dashboard', 'mr-1')); ?> <?php echo e(__('Dashboard')); ?></a>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
        <a href="<?php echo e(route('dashboard.allurl')); ?>"
            class="nav-item <?php echo e((request()->route()->getName() === 'dashboard.allurl') ? 'border-l-2 border-orange-500':''); ?>">
            <?php echo e(svg('icon-link', 'mr-1')); ?> <?php echo e(__('URL List')); ?></a>
        <a href="<?php echo e(route('user.index')); ?>"
            class="nav-item <?php echo e((request()->route()->getName() === 'user.index') ? 'border-l-2 border-orange-500':''); ?>">
            <?php echo e(svg('icon-people', 'mr-1')); ?> <?php echo e(__('User List')); ?></a>
        <a href="<?php echo e(route('dashboard.about')); ?>"
            class="nav-item <?php echo e((request()->route()->getName() === 'dashboard.about') ? 'border-l-2 border-orange-500':''); ?>">
            <?php echo e(svg('icon-about-system', 'mr-1')); ?> <?php echo e(__('About')); ?></a>
    <?php endif; ?>
</div>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/partials/header-localmenu_mobile.blade.php ENDPATH**/ ?>