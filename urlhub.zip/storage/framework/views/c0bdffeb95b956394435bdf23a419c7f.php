<?php
    $routeName = request()->route()->getName();
?>

<nav class="bg-uh-bg-1 pt-1">
    <div class="hidden layout-container sm:flex px-4 sm:px-6 lg:px-8 croll-smooth hover:scroll-auto">
        <a href="<?php echo e(route('dashboard')); ?>"
            class="mr-8 py-3 font-semibold hover:text-uh-blue-2 transition duration-100 ease-in-out border-b-2 border-transparent
                <?php echo e(($routeName === 'dashboard') ?
                'text-uh-blue-2 !border-orange-500' :
                'text-slate-600 hover:border-slate-300'); ?>"
        >
            <?php echo e(svg('icon-dashboard', 'mr-1')); ?>
            <span class="<?php if($routeName === 'dashboard'): ?> text-black <?php endif; ?>"><?php echo e(__('Dashboard')); ?></span>
        </a>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <a href="<?php echo e(route('dashboard.allurl')); ?>"
                class="mr-8 py-3 font-semibold hover:text-uh-blue-2 transition duration-100 ease-in-out border-b-2 border-transparent
                    <?php echo e(($routeName === 'dashboard.allurl') ?
                    'text-uh-blue-2 !border-orange-500' :
                    'text-slate-600 hover:border-slate-300'); ?>"
            >
                <?php echo e(svg('icon-link', 'mr-1')); ?>
                <span class="<?php if($routeName === 'dashboard.allurl'): ?> text-black <?php endif; ?>"><?php echo e(__('URL List')); ?></span>
            </a>
            <a href="<?php echo e(route('user.index')); ?>"
                class="mr-8 py-3 font-semibold hover:text-uh-blue-2 transition duration-100 ease-in-out border-b-2 border-transparent
                    <?php echo e(($routeName === 'user.index') ?
                    'text-uh-blue-2 !border-orange-500' :
                    'text-slate-600 hover:border-slate-300'); ?>"
            >
                <?php echo e(svg('icon-people', 'mr-1')); ?>
                <span class="<?php if($routeName === 'user.index'): ?> text-black <?php endif; ?>"><?php echo e(__('User List')); ?></span>
            </a>
            <a href="<?php echo e(route('dashboard.about')); ?>"
                class="mr-8 py-3 font-semibold hover:text-uh-blue-2 transition duration-100 ease-in-out border-b-2 border-transparent
                    <?php echo e(($routeName === 'dashboard.about') ?
                    'text-uh-blue-2 !border-orange-500' :
                    'text-slate-600 hover:border-slate-300'); ?>"
            >
                <?php echo e(svg('icon-about-system', 'mr-1')); ?>
                <span class="<?php if($routeName === 'dashboard.about'): ?> text-black <?php endif; ?>"><?php echo e(__('About')); ?></span>
            </a>
        <?php endif; ?>
    </div>
</nav>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/partials/header-localmenu.blade.php ENDPATH**/ ?>