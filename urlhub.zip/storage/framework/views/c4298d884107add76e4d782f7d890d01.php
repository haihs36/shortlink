<?php $__env->startSection('title', __('URLs List')); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <div class="common-card-style">
            <div class="card_header__v2">
                <div class="w-1/2">
                    <span class="text-2xl text-uh-1">
                        <?php echo e(__('List of All URLs')); ?>

                    </span>
                </div>
                <div class="w-1/2 text-right">
                    <a href="<?php echo e(route('dashboard.allurl.u-guest')); ?>" title="<?php echo e(__('Shortened long links by Guest')); ?>" class="btn btn-secondary">
                        <?php echo e(__('By Guest')); ?>

                    </a>
                </div>
            </div>

            <?php echo $__env->make('partials/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('table.url-list-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-1408031604-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/backend/url-list.blade.php ENDPATH**/ ?>