<span>
    <input name="custom_key" wire:model.live="keyword"
        class="px-2 text-2xl text-orange-400 bg-transparent border-b-4 border-emerald-500 focus:outline-none
        
        focus:border-emerald-500
        border-0 focus:ring-transparent">

    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span class="font-light text-base text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
</span>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/livewire/validation/validate-custom-keyword.blade.php ENDPATH**/ ?>