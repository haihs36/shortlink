<?php
    $tClick = n_abb($clicks);
    $uClick = n_abb($uniqueClicks);
    $title = $tClick.' '.__('Clicks').' / '.$uClick.' '.__('Uniques');
?>

<div title="<?php echo e($title); ?>">
    <?php echo e($tClick); ?> / <?php echo e($uClick); ?>

    <?php echo e(svg('icon-chart-line-alt', 'ml-2 text-amber-600')); ?>
</div>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/components/table/visit.blade.php ENDPATH**/ ?>