<div>
    <a href="<?php echo e($shortLink); ?>" title="<?php echo e($keyword); ?>" target="_blank" class="font-light text-sky-800">
        <?php echo e(str()->limit($keyword, 12)); ?>

    </a>
</div>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/components/table/keyword.blade.php ENDPATH**/ ?>