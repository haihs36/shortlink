<?php $__env->startSection('title', __('Edit Link').' "'.$url->keyword.'"'.' ‹ '.str()->title(auth()->user()->name)); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="flex flex-wrap">
        <div class="md:w-3/12 flex justify-between">
            <div class="px-4 sm:px-0">
                <h3 class="text-lg font-medium text-slate-900"><?php echo e(__('Edit URL Details')); ?></h3>
                <br>
                <div class="inline sm:block mr-2 text-sm text-slate-600">
                    <?php echo e(svg('icon-person', 'mr-1')); ?>
                    <?php echo e($url->author->name); ?>

                </div>
                <div class="inline sm:block text-sm text-slate-600">
                    <?php echo e(svg('icon-calendar', 'mr-1')); ?>
                    <span title="<?php echo e($url->created_at->toDayDateTimeString()); ?>"><?php echo e($url->created_at->diffForHumans()); ?></span>
                </div>

                <?php if($url->created_at != $url->updated_at): ?>
                <div class="inline sm:block text-sm text-slate-600">
                    <?php echo e(svg('icon-updated', 'mr-1 font-bold')); ?>
                    <span title="<?php echo e($url->updated_at->toDayDateTimeString()); ?>"><?php echo e($url->updated_at->diffForHumans()); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="w-full md:w-8/12 lg:w-6/12 mt-5 md:mt-0 md:ml-4">
            <form method="post" action="<?php echo e(route('dboard.url.edit.store', $url)); ?>">
            <?php echo csrf_field(); ?>
                <div class="common-card-style">
                    <div class="grid grid-cols-6 gap-6">
                        <div class="col-span-6 lg:col-span-4">
                            <label for="short-url" class="form-label"><?php echo e(__('Short URL')); ?></label>
                            <span class="short-url text-uh-blue"><?php echo e(urlFormat($url->short_url, scheme: false)); ?></span>
                        </div>

                        <div class="col-span-6">
                            <label class="form-label"><?php echo e(__('Title')); ?></label>
                            <input name="title" placeholder="<?php echo e(__('Title')); ?>" required
                                value="<?php echo e($url->title); ?>" class="form-input">
                        </div>

                        <div class="col-span-6">
                            <label for="long-url" class="form-label"><?php echo e(__('Destination URL')); ?></label>
                            <input id="long-url" name="long_url" placeholder="http://www.my_long_url.com"
                                required value="<?php echo e($url->destination); ?>" class="form-input">
                        </div>
                    </div>

                    <div class="flex items-center justify-end mt-4 text-right">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <?php echo e(__('Save Changes')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/backend/edit.blade.php ENDPATH**/ ?>