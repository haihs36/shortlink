<?php $__env->startSection('title', __('All Users')); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <div class="common-card-style">
            <div class="card_header__v2"><?php echo e(__('All Users')); ?></div>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('table.user-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-375125108-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/backend/user/index.blade.php ENDPATH**/ ?>