<?php $__env->startSection('title', __('Login')); ?>

<?php $__env->startSection('css_class', 'auth'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col min-h-screen sm:justify-center items-center pt-6 sm:pt-0">

        <div class="font-bold text-uh-blue text-4xl sm:text-6xl"><?php echo e(config('app.name')); ?></div>

        <?php if(session()->has('login_error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session()->get('login_error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php echo e(session()->forget('login_error')); ?>

        <?php endif; ?>

        <div class="auth-card">
            <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
            <?php echo csrf_field(); ?>
                <div>
                    <label for="email" class="form-label">
                        <?php echo e(__('E-Mail / Username')); ?>

                    </label>
                    <input name="identity" class="form-input mt-1" value="<?php echo e(old('identity')); ?>" required autofocus>
                </div>

                <div class="mt-4">
                    <label for="password" class="form-label">
                        <?php echo e(__('Password')); ?>

                    </label>
                    <input type="password" name="password" class="form-input mt-1" autocomplete="current-password" required>
                </div>

                <div class="flex items-center justify-end mt-4">
                    <a href="<?php echo e(route('password.request')); ?>" class="text-sm text-slate-600 hover:text-slate-900 underline">
                        <?php echo e(__('Forgot your password?')); ?>

                    </a>

                    <button type="submit" class="btn btn-primary ml-4">
                        <?php echo e(__('Log in')); ?>

                    </button>
                </div>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/auth/login.blade.php ENDPATH**/ ?>