<?php if($errors->any()): ?>
    <div class="block mb-4 pl-3 pr-4 py-2 font-medium text-base text-orange-700 bg-orange-50 border-l-4 border-orange-400" role="alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?> <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php elseif(session('flash_success')): ?>
    <div class="block mb-4 pl-3 pr-4 py-2 font-medium text-base text-emerald-700 bg-emerald-50 border-l-4 border-emerald-400" role="alert">
        <?php echo e(session('flash_success')); ?>

    </div>
<?php elseif(session('flash_error')): ?>
    <div class="block mb-4 pl-3 pr-4 py-2 font-medium text-base text-red-700 bg-red-50 border-l-4 border-red-400" role="alert">
        <?php echo e(session('flash_error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/partials/messages.blade.php ENDPATH**/ ?>