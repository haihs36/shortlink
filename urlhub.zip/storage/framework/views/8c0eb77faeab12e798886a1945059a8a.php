<?php $__env->startSection('title', __('Dashboard')); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <div class="grid gird-cols-1 md:grid-cols-4 gap-7 mb-8">
            <div class="bg-uh-bg-1 p-4 sm:rounded-lg
                border-y border-uh-border-color sm:border-none sm:shadow-md"
            >
                <div class="flex flex-row space-x-4 items-center">
                    <?php echo e(svg('icon-link', 'mr-1.5 text-emerald-600 text-3xl')); ?>
                    <div>
                        <p class="text-gray-400 text-sm font-medium uppercase leading-4">Total Links</p>
                        <p class="text-2xl font-bold text-gray-900 inline-flex items-center space-x-2">
                            <?php echo e(n_abb($url->currentUserUrlCount(auth()->id()))); ?>

                        </p>
                    </div>
                </div>
            </div>
            <div class="bg-uh-bg-1 p-4 sm:rounded-lg
                border-y border-uh-border-color sm:border-none sm:shadow-md"
            >
                <div class="flex flex-row space-x-4 items-center">
                    <?php echo e(svg('icon-chart-line-alt', 'mr-1.5 text-amber-600 text-3xl')); ?>
                    <div>
                        <p class="text-gray-400 text-sm font-medium uppercase leading-4">Total Clicks</p>
                        <p class="text-2xl font-bold text-gray-900 inline-flex items-center space-x-2">
                            <?php echo e($urlVisitCount); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-card-style">
            <div class="card_header__v2">
                <div class="w-1/2">
                    <span class="text-2xl text-uh-1"><?php echo e(__('My URLs')); ?></span>
                </div>
                <div class="w-1/2 text-right">
                    <a href="<?php echo e(url('./')); ?>" target="_blank" title="<?php echo e(__('Add URL')); ?>" class="btn btn-primary">
                        <?php echo e(svg('icon-add-link', '!h-[1.5em] mr-1')); ?>
                        <?php echo e(__('Add URL')); ?>

                    </a>
                </div>
            </div>

            <?php echo $__env->make('partials/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('table.my-url-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-2424796877-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>