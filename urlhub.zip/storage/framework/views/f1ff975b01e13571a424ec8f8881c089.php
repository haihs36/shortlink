<?php use \App\Helpers\Helper; ?>

<div>
    <span title="<?php echo e($title); ?> ">
        <?php echo e(str()->limit($title, $limit)); ?>

    </span>

    <br>

    <a href="<?php echo e($destination); ?>" target="_blank" title="<?php echo e($destination); ?>" rel="noopener noreferrer" class="text-[#6c6c6c]">
        <?php echo e(Helper::urlFormat($destination, $limit)); ?>

    </a>
</div>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/components/table/destination.blade.php ENDPATH**/ ?>