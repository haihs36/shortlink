<?php $__env->startSection('title', __('Edit Account').' "'.$user->name.'"'.' ‹ '.str()->title(auth()->user()->name)); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="flex flex-wrap">
        <div class="md:w-3/12 flex justify-between">
            <div class="px-4 sm:px-0">
                <h3 class="text-lg font-medium text-slate-900"><?php echo e(__('Account Information')); ?></h3>

                <p class="mt-1 text-sm text-slate-600">
                    <?php echo e(__("Update your account information.")); ?>

                </p>
            </div>
        </div>
        <div class="w-full md:w-8/12 lg:w-6/12 mt-5 md:mt-0 md:ml-4">
            <form method="post" action="<?php echo e(route('user.update', $user)); ?>">
            <?php echo csrf_field(); ?>
                <div class="common-card-style">
                    <div class="grid grid-cols-6 gap-6">
                        <div class="col-span-6 lg:col-span-4">
                            <label class="form-label"><?php echo e(__('Username')); ?></label>
                            <input name="name" value="<?php echo e($user->name); ?>" class="form-input bg-slate-100 text-slate-700 mt-1" disabled>
                            <small class="block text-red-400"><i><?php echo e(__('Usernames cannot be changed.')); ?></i></small>
                        </div>
                        <div class="col-span-6 lg:col-span-4">
                            <label class="form-label"><?php echo e(__('E-mail Address')); ?></label>
                            <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-input mt-1">
                        </div>
                    </div>

                    <div class="flex items-center justify-end mt-4 text-right">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <?php echo e(__('Save')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/backend/user/account.blade.php ENDPATH**/ ?>