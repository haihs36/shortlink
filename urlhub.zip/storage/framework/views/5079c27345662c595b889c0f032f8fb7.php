<span class="font-semibold">
    <a href="<?php echo e(route('dashboard.allurl.u-user', $name)); ?>">
        <?php echo e($name); ?>

    </a>
</span>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/components/table/author.blade.php ENDPATH**/ ?>