<?php $__env->startSection('css_class', 'frontend view_short'); ?>
<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto mb-12">
        <div class="md:w-10/12 mt-6 lg:mt-8 px-4 sm:p-6">
            <div class="text-xl sm:text-2xl lg:text-3xl mb-4"><?php echo e($url->title); ?></div>

            <ul class="mb-4">
                <li class="inline-block pr-4">
                    <?php echo e(svg('icon-calendar')); ?>
                    <i><?php echo e($url->created_at->toDayDateTimeString()); ?></i>
                </li>
                <li class="inline-block pr-4 mt-4 lg:mt-0">
                    <?php echo e(svg('icon-chart-line-alt')); ?>
                    <i>
                        <span title="<?php echo e(number_format($visitsCount)); ?>" class="font-bold">
                            <?php echo e(n_abb($visitsCount)); ?>

                        </span>
                    </i>
                </li>
            </ul>
        </div>
        <div class="common-card-style flex flex-wrap mt-6 sm:mt-0 px-4 py-5 sm:p-6">
            <?php if(config('urlhub.qrcode')): ?>
                <div class="w-full md:w-1/4 flex justify-center">
                    <img class="qrcode h-fit" src="<?php echo e($qrCode->getDataUri()); ?>" alt="QR Code">
                </div>
            <?php endif; ?>
            <div class="w-full md:w-3/4 mt-8 sm:mt-0">
                <div class="text-right pr-6">
                    <button id="clipboard_shortlink" class="mr-6 hover:text-indigo-600"
                        title="<?php echo e(__('Copy the shortened URL to clipboard')); ?>"
                        data-clipboard-text="<?php echo e($url->short_url); ?>"
                    >
                        <?php echo e(svg('icon-clone', 'mr-1')); ?>
                    </button>

                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->hasRole('admin') || (auth()->user()->id === $url->user_id)): ?>
                            <a href="<?php echo e(route('dboard.url.edit.show', $url)); ?>" title="<?php echo e(__('Edit')); ?>" class="mr-6 hover:text-indigo-600">
                                <?php echo e(svg('icon-edit')); ?>
                            </a>
                            <a href="<?php echo e(route('su_delete', $url)); ?>" title="<?php echo e(__('Delete')); ?>" class="hover:text-red-600">
                                <?php echo e(svg('icon-trash')); ?>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <br>

                <span class="font-bold text-uh-blue-2 text-xl sm:text-2xl">
                    <a href="<?php echo e($url->short_url); ?>" target="_blank" id="copy">
                        <?php echo e(urlFormat($url->short_url, scheme: false)); ?>

                    </a>
                </span>

                <div class="mt-2">
                    <div class="flex gap-x-2">
                        <div class="hidden md:block"><?php echo e(svg('arrow-turn-right')); ?></div>
                        <div class="break-all max-w-2xl">
                            <a href="<?php echo e($url->destination); ?>" target="_blank" rel="noopener noreferrer" class="redirect-anchor">
                                <?php echo e($url->destination); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="mt-20">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split(\App\Livewire\Chart\LinkVisitChart::class, ['model' => $url]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3532852620-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/frontend/short.blade.php ENDPATH**/ ?>