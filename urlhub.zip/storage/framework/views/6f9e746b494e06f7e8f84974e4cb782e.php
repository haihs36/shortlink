<div>
    <span title="<?php echo e($date->toDayDateTimeString()); ?> ">
        <?php echo e($date->shortRelativeDiffForHumans()); ?>

    </span>
</div>
<?php /**PATH D:\project\shortlink\urlhub\resources\views/components/table/date-created.blade.php ENDPATH**/ ?>