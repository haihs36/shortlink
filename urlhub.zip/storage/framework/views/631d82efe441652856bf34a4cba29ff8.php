<?php use \App\Services\KeyGeneratorService; ?>



<?php $__env->startSection('title', __('About System')); ?>
<?php $__env->startSection('content'); ?>
    <main class="page_about max-w-4xl">
        <div class="flex flex-wrap gap-4 mb-4 justify-end">
            <div class="bg-uh-bg-1 p-4 sm:rounded-lg w-full md:w-2/6
                border-y border-uh-border-color sm:border-none sm:shadow-md"
            >
                <div class="flex flex-row space-x-4 items-center">
                    <div>
                        <p class="text-[#4f5b93] text-sm font-medium leading-4">PHP</p>
                        <p class="text-2xl font-bold text-gray-600 inline-flex items-center space-x-2">
                            <?php echo e(phpversion()); ?>

                        </p>
                    </div>
                </div>
            </div>
            <div class="bg-uh-bg-1 p-4 sm:rounded-lg w-full md:w-2/6
                border-y border-uh-border-color sm:border-none sm:shadow-md"
            >
                <div class="flex flex-row space-x-4 items-center">
                    <div>
                        <p class="text-[#ff2d20] text-sm font-medium leading-4">Laravel</p>
                        <p class="text-2xl font-bold text-gray-600 inline-flex items-center space-x-2">
                            <?php echo e(app()->version()); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>

        <br>

        <div class="common-card-style">
            <div class="card_header__sub_header">Links</div>
            <dl>
                <?php
                    $urlCount = n_abb($url->count());
                    $visitCount = n_abb($visit->count());
                    $userUrlCount = n_abb($url->userUrlCount());
                    $userLinkVisitCount = n_abb($visit->userLinkVisitCount());
                    $guestUrlCount = n_abb($url->guestUserUrlCount());
                    $guestUserLinkVisitCount = n_abb($visit->guestUserLinkVisitCount());
                ?>
                <dt>Total</dt>
                <dd><?php echo e($urlCount); ?> (<?php echo e($visitCount); ?> visits)</dd>

                <dt>User</dt>
                <dd><?php echo e($userUrlCount); ?> (<?php echo e($userLinkVisitCount); ?> visits)</dd>

                <dt>Guest</dt>
                <dd><?php echo e($guestUrlCount); ?> (<?php echo e($guestUserLinkVisitCount); ?> visits)</dd>
            </dl>

            <div class="card_header__sub_header">Users</div>
            <dl>
                <dt>User</dt>
                <dd><?php echo e(n_abb($user->count())); ?></dd>

                <dt>Guest</dt>
                <dd><?php echo e(n_abb($user->totalGuestUsers())); ?></dd>
            </dl>

            <div class="card_header__sub_header">Random String</div>
            <dl>
                <dt>Possible Output</dt>
                <dd>
                    <?php
                        $number = strlen(KeyGeneratorService::ALPHABET);
                        $powNumber = config('urlhub.keyword_length');
                        $result = number_format($keyGenerator->possibleOutput());
                    ?>
                    ( <?php echo e($number); ?><sup><?php echo e($powNumber); ?></sup> ) <?php echo e($result); ?>

                </dd>

                <dt>Generated</dt>
                <dd><?php echo e(number_format($keyGenerator->totalKey())); ?></dd>
            </dl>
        </div>

        <br>

        <div class="common-card-style">
            <div class="card_header"><?php echo e(__('Configuration')); ?></div>

            <div class="card_header__sub_header">Shortened Links</div>
            <dl>
                <?php
                    $hashLength = config('urlhub.keyword_length');
                    $customKeywordMinLength = config('urlhub.custom_keyword_min_length');
                    $customKeywordMaxLength = config('urlhub.custom_keyword_max_length');
                    $redirectCacheMaxAge = config('urlhub.redirect_cache_max_age');
                ?>
                <dt><code>keyword_length</code></dt>
                <dd><?php echo e($hashLength.' '.str()->plural('character', $hashLength)); ?></dd>

                <dt><code>custom_keyword_min_length</code></dt>
                <dd><?php echo e($customKeywordMinLength.' '.str()->plural('character', $customKeywordMinLength)); ?></dd>

                <dt><code>custom_keyword_max_length</code></dt>
                <dd><?php echo e($customKeywordMaxLength.' '.str()->plural('character', $customKeywordMaxLength)); ?></dd>

                <?php
                    $domainBlacklist = collect(config('urlhub.domain_blacklist'))
                        ->sort()->toArray();
                ?>
                <dt class="mt-2"><code>domain_blacklist</code></dt>
                <dd class="mt-2">
                    <div class="bg-gray-50 p-2 border border-gray-300 rounded text-sm">
                        <?php if(! empty($domainBlacklist)): ?>
                            <code><?php echo e(implode(", ", $domainBlacklist)); ?></code>
                        <?php else: ?>
                            <code>None</code>
                        <?php endif; ?>
                    </div>
                </dd>

                <?php
                    $reservedKey = collect(config('urlhub.reserved_keyword'))
                        ->sort()->toArray();
                ?>
                <dt class="mt-2 mb-2">Reserved Keywords</dt>
                <dd class="mt-2 mb-2">
                    <div class="bg-gray-50 p-2 border border-gray-300 rounded text-sm">
                        <p><b>Config</b></p>
                        <code><?php echo e(implode(", ", $reservedKey)); ?></code>

                        <br> <br>

                        <p><b>Registered routes</b></p>
                        <code><?php echo e(implode(", ", \App\Helpers\Helper::routeList())); ?></code>

                        <br> <br>

                        <p><b>Public Folder</b></p>
                        <code><?php echo e(implode(", ", \App\Helpers\Helper::publicPathList())); ?></code>
                    </div>
                </dd>

                <dt><code>web_title</code></dt>
                <dd>
                    <code class="config-value-bool"><?php echo e(var_export(config('urlhub.web_title'))); ?></code>
                </dd>

                <dt><code>redirect_status_code</code></dt>
                <dd><?php echo e(config('urlhub.redirect_status_code')); ?></dd>

                <dt><code>redirect_cache_max_age</code></dt>
                <dd><?php echo e($redirectCacheMaxAge.' '.str()->plural('second', $redirectCacheMaxAge)); ?></dd>

                <dt><code>track_bot_visits</code></dt>
                <dd>
                    <code class="config-value-bool"><?php echo e(var_export(config('urlhub.track_bot_visits'))); ?></code>
                </dd>
            </dl>

            <div class="card_header__sub_header">Guest / Unregistered Users</div>
            <dl>
                <dt>Can create short links</dt>
                <dd>
                    <code class="config-value-bool"><?php echo e(var_export(config('urlhub.public_site'))); ?></code>
                </dd>

                <dt>Can sign up</dt>
                <dd>
                    <code class="config-value-bool"><?php echo e(var_export(config('urlhub.registration'))); ?></code>
                </dd>
            </dl>

            <div class="card_header__sub_header">QRCode</div>
            <dl>
                <dt>Enabled</dt>
                <dd>
                    <code class="config-value-bool"><?php echo e(var_export(config('urlhub.qrcode'))); ?></code>
                </dd>

                <dt>Size</dt>
                <dd><?php echo e(config('urlhub.qrcode_size')); ?> px</dd>

                <dt>Margin</dt>
                <dd><?php echo e(config('urlhub.qrcode_margin')); ?> px</dd>

                <dt>Format</dt>
                <dd><?php echo e(config('urlhub.qrcode_format')); ?></dd>

                <dt>Error correction levels</dt>
                <dd><?php echo e(config('urlhub.qrcode_error_correction')); ?></dd>

                <dt>Round block</dt>
                <dd>
                    <code class="config-value-bool"><?php echo e(var_export(config('urlhub.qrcode_round_block_size'))); ?></code>
                </dd>
            </dl>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\shortlink\urlhub\resources\views/backend/about.blade.php ENDPATH**/ ?>