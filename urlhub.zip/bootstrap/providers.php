<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\HelperServiceProvider::class,
    App\Providers\FortifyServiceProvider::class,
];
