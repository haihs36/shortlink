The files in this directory that have the word 'Helper' in them are
autoloaded by HelperServiceProvider so they are available as global
functions.

If you do not want a particular helper file loaded globally, place 
them outside of the Helpers/Global directory.

---

File-file dalam direktori ini yang memiliki kata 'Helper' di dalamnya
dan secara otomatis dimuat oleh HelperServiceProvider, sehingga
mereka tersedia sebagai fungsi global.

Jika Anda tidak ingin file helper tertentu dimuat secara global, maka
letakkanlah file tersebut di luar direktori Helpers/Global.
